package library;

import java.util.List;
import java.util.Scanner;

/**
 * Main entry point for the Library Management System.
 * Provides a complete menu-driven interface for all library operations.
 */
public class LibrarySystem {

    private static final Library library = new Library("City Central Library");
    private static final Scanner scanner  = new Scanner(System.in);

    public static void main(String[] args) {
        loadSampleData();
        printWelcomeBanner();

        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("  Enter your choice: ");

            switch (choice) {
                case 1  -> addBook();
                case 2  -> registerMember();
                case 3  -> library.displayAllBooks();
                case 4  -> library.displayAvailableBooks();
                case 5  -> searchBooks();
                case 6  -> borrowBook();
                case 7  -> returnBook();
                case 8  -> viewMemberDetails();
                case 9  -> library.displayAllMembers();
                case 10 -> library.displayLibraryReport();
                case 11 -> payFine();
                case 12 -> removeBook();
                case 0  -> { running = false; printGoodbye(); }
                default -> System.out.println("  ⚠  Invalid choice. Please try again.\n");
            }
        }
        scanner.close();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Menu Handlers
    // ══════════════════════════════════════════════════════════════════════════

    private static void addBook() {
        printSectionHeader("ADD NEW BOOK");
        try {
            String isbn   = readString("  Enter ISBN   : ");
            String title  = readString("  Enter Title  : ");
            String author = readString("  Enter Author : ");
            String genre  = readString("  Enter Genre  : ");

            Book book = new Book(isbn, title, author, genre);
            if (library.addBook(book))
                System.out.println("  ✅ Book \"" + title + "\" added successfully!\n");
        } catch (IllegalArgumentException e) {
            System.out.println("  ❌ Error: " + e.getMessage() + "\n");
        }
    }

    private static void registerMember() {
        printSectionHeader("REGISTER NEW MEMBER");
        try {
            String id      = readString("  Enter Member ID : ");
            String name    = readString("  Enter Name      : ");
            String contact = readString("  Enter Contact   : ");

            Member member = new Member(id, name, contact);
            if (library.addMember(member))
                System.out.println("  ✅ Member \"" + name + "\" registered successfully!\n");
        } catch (IllegalArgumentException e) {
            System.out.println("  ❌ Error: " + e.getMessage() + "\n");
        }
    }

    private static void searchBooks() {
        printSectionHeader("SEARCH BOOKS");
        String keyword = readString("  Enter keyword (title / author / genre): ");
        List<Book> results = library.searchBooks(keyword);

        System.out.println("\n  Found " + results.size() + " result(s) for \"" + keyword + "\":\n");
        if (results.isEmpty()) {
            System.out.println("  No books matched your search.\n");
        } else {
            results.forEach(Book::displayInfo);
        }
    }

    private static void borrowBook() {
        printSectionHeader("BORROW BOOK");
        String memberId = readString("  Enter Member ID  : ");
        String isbn     = readString("  Enter Book ISBN  : ");
        library.borrowBook(memberId, isbn);
        System.out.println();
    }

    private static void returnBook() {
        printSectionHeader("RETURN BOOK");
        String memberId = readString("  Enter Member ID  : ");
        String isbn     = readString("  Enter Book ISBN  : ");
        library.returnBook(memberId, isbn);
        System.out.println();
    }

    private static void viewMemberDetails() {
        printSectionHeader("MEMBER DETAILS");
        String memberId = readString("  Enter Member ID: ");
        Member member = library.findMemberById(memberId);
        if (member == null) {
            System.out.println("  ⚠  Member not found.\n");
        } else {
            System.out.println();
            member.displayInfo();
        }
    }

    private static void payFine() {
        printSectionHeader("PAY FINE");
        String memberId = readString("  Enter Member ID : ");
        Member member = library.findMemberById(memberId);
        if (member == null) {
            System.out.println("  ⚠  Member not found.\n");
            return;
        }
        System.out.printf("  Outstanding fine for %s: ₹%.2f%n", member.getName(), member.getFineAmount());
        if (member.getFineAmount() <= 0) {
            System.out.println("  No fine to pay.\n");
            return;
        }
        double amount = readDouble("  Enter amount to pay: ₹");
        try {
            member.payFine(amount);
        } catch (IllegalArgumentException e) {
            System.out.println("  ❌ " + e.getMessage());
        }
        System.out.println();
    }

    private static void removeBook() {
        printSectionHeader("REMOVE BOOK");
        String isbn = readString("  Enter Book ISBN: ");
        if (library.removeBook(isbn))
            System.out.println("  ✅ Book removed successfully.\n");
        else
            System.out.println();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Sample Data
    // ══════════════════════════════════════════════════════════════════════════

    private static void loadSampleData() {
        // Sample books
        library.addBook(new Book("978-3-16-148410-0", "Java Programming Guide",        "John Smith",    "Programming"));
        library.addBook(new Book("978-0-262-03384-8", "Introduction to Algorithms",    "Thomas Cormen", "Computer Science"));
        library.addBook(new Book("978-0-13-468599-1", "Effective Java",                "Joshua Bloch",  "Programming"));
        library.addBook(new Book("978-0-13-235088-4", "Clean Code",                   "Robert Martin", "Programming"));
        library.addBook(new Book("978-0-20-161622-4", "The Pragmatic Programmer",      "David Thomas",  "Software Engineering"));
        library.addBook(new Book("978-0-59-651798-1", "Learning Python",               "Mark Lutz",     "Programming"));
        library.addBook(new Book("978-0-06-112008-4", "To Kill a Mockingbird",         "Harper Lee",    "Fiction"));
        library.addBook(new Book("978-0-74-320348-1", "The Hitchhiker's Guide",        "Douglas Adams", "Science Fiction"));

        // Sample members
        library.addMember(new Member("M001", "Alice Johnson",  "alice@email.com"));
        library.addMember(new Member("M002", "Bob Williams",   "bob@email.com"));
        library.addMember(new Member("M003", "Carol Martinez", "carol@email.com"));

        // Pre-borrow one book so the demo shows a borrowed state
        library.borrowBook("M001", "978-0-13-468599-1");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  UI Helpers
    // ══════════════════════════════════════════════════════════════════════════

    private static void printWelcomeBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║     LIBRARY MANAGEMENT SYSTEM  v1.0      ║");
        System.out.println("  ║       " + centerPad(library.getLibraryName(), 36) + "║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println("  " + library.getTotalBooks() + " books  |  " + library.getTotalMembers() + " members loaded.");
        System.out.println();
    }

    private static void printMainMenu() {
        System.out.println("  ┌──────────────────────────────────────────┐");
        System.out.println("  │              MAIN MENU                   │");
        System.out.println("  ├──────────────────────────────────────────┤");
        System.out.println("  │  BOOKS                                   │");
        System.out.println("  │   1. Add New Book                        │");
        System.out.println("  │   3. Display All Books                   │");
        System.out.println("  │   4. Display Available Books             │");
        System.out.println("  │   5. Search Books                        │");
        System.out.println("  │  12. Remove a Book                       │");
        System.out.println("  ├──────────────────────────────────────────┤");
        System.out.println("  │  MEMBERS                                 │");
        System.out.println("  │   2. Register New Member                 │");
        System.out.println("  │   8. View Member Details                 │");
        System.out.println("  │   9. Display All Members                 │");
        System.out.println("  ├──────────────────────────────────────────┤");
        System.out.println("  │  TRANSACTIONS                            │");
        System.out.println("  │   6. Borrow Book                         │");
        System.out.println("  │   7. Return Book                         │");
        System.out.println("  │  11. Pay Fine                            │");
        System.out.println("  ├──────────────────────────────────────────┤");
        System.out.println("  │  REPORTS                                 │");
        System.out.println("  │  10. Library Report                      │");
        System.out.println("  ├──────────────────────────────────────────┤");
        System.out.println("  │   0. Exit                                │");
        System.out.println("  └──────────────────────────────────────────┘");
    }

    private static void printSectionHeader(String title) {
        System.out.println("\n  ┌── " + title + " " + "─".repeat(Math.max(0, 36 - title.length())) + "┐");
        System.out.println();
    }

    private static void printGoodbye() {
        System.out.println("\n  Thank you for using the Library Management System. Goodbye! 📚\n");
    }

    private static String centerPad(String text, int width) {
        if (text.length() >= width) return text.substring(0, width);
        int padding = width - text.length();
        int left  = padding / 2;
        int right = padding - left;
        return " ".repeat(left) + text + " ".repeat(right);
    }

    // ── Input helpers ─────────────────────────────────────────────────────────
    private static String readString(String prompt) {
        System.out.print(prompt);
        String line = scanner.nextLine().trim();
        while (line.isEmpty()) {
            System.out.print("  ⚠  Input cannot be empty. " + prompt);
            line = scanner.nextLine().trim();
        }
        return line;
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  ⚠  Please enter a valid number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  ⚠  Please enter a valid amount.");
            }
        }
    }
}
