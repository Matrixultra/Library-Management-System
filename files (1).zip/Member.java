package library;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a library member.
 * Manages the member's personal details and their borrowed books.
 */
public class Member {
    private static final int MAX_BORROW_LIMIT = 5;

    private String memberId;
    private String name;
    private String contact;
    private List<Book> borrowedBooks;
    private double fineAmount;

    public Member(String memberId, String name, String contact) {
        if (memberId == null || memberId.trim().isEmpty()) throw new IllegalArgumentException("Member ID cannot be empty.");
        if (name == null || name.trim().isEmpty())         throw new IllegalArgumentException("Name cannot be empty.");
        if (contact == null || contact.trim().isEmpty())   throw new IllegalArgumentException("Contact cannot be empty.");

        this.memberId      = memberId.trim();
        this.name          = name.trim();
        this.contact       = contact.trim();
        this.borrowedBooks = new ArrayList<>();
        this.fineAmount    = 0.0;
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getMemberId()  { return memberId; }
    public String getName()      { return name; }
    public String getContact()   { return contact; }
    public double getFineAmount(){ return fineAmount; }
    public List<Book> getBorrowedBooks() { return Collections.unmodifiableList(borrowedBooks); }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setMemberId(String memberId) {
        if (memberId == null || memberId.trim().isEmpty()) throw new IllegalArgumentException("Member ID cannot be empty.");
        this.memberId = memberId.trim();
    }
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Name cannot be empty.");
        this.name = name.trim();
    }
    public void setContact(String contact) {
        if (contact == null || contact.trim().isEmpty()) throw new IllegalArgumentException("Contact cannot be empty.");
        this.contact = contact.trim();
    }

    // ── Borrow / Return ───────────────────────────────────────────────────────
    /**
     * Borrow a book if it is available and member hasn't hit the limit.
     * @return true on success, false otherwise
     */
    public boolean borrowBook(Book book) {
        if (!book.isAvailable()) {
            System.out.println("  ⚠  Book is not available.");
            return false;
        }
        if (borrowedBooks.size() >= MAX_BORROW_LIMIT) {
            System.out.println("  ⚠  Borrow limit reached (" + MAX_BORROW_LIMIT + " books max).");
            return false;
        }
        borrowedBooks.add(book);
        book.setAvailable(false);
        book.setBorrowedByMemberId(memberId);
        return true;
    }

    /**
     * Return a book.  Calculates fine if overdue (₹5 per day).
     * @return fine charged for this return (0 if on time)
     */
    public double returnBook(Book book) {
        if (!borrowedBooks.contains(book)) {
            System.out.println("  ⚠  This book is not borrowed by member " + memberId + ".");
            return -1;
        }

        double fine = 0.0;
        if (book.getDueDate() != null) {
            java.time.LocalDate today = java.time.LocalDate.now();
            long daysLate = java.time.temporal.ChronoUnit.DAYS.between(book.getDueDate(), today);
            if (daysLate > 0) {
                fine = daysLate * 5.0;   // ₹5 per overdue day
                fineAmount += fine;
            }
        }

        borrowedBooks.remove(book);
        book.setAvailable(true);
        book.setDueDate(null);
        book.setBorrowedByMemberId(null);
        return fine;
    }

    public void payFine(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Payment must be positive.");
        if (amount > fineAmount) amount = fineAmount;
        fineAmount -= amount;
        System.out.printf("  ✅ Payment of ₹%.2f accepted. Remaining fine: ₹%.2f%n", amount, fineAmount);
    }

    // ── Display ───────────────────────────────────────────────────────────────
    public void displayInfo() {
        System.out.println("  Member ID : " + memberId);
        System.out.println("  Name      : " + name);
        System.out.println("  Contact   : " + contact);
        System.out.printf ("  Fine      : ₹%.2f%n", fineAmount);
        System.out.println("  Books     : " + borrowedBooks.size() + " / " + MAX_BORROW_LIMIT);
        if (!borrowedBooks.isEmpty()) {
            System.out.println("  Borrowed  :");
            for (Book b : borrowedBooks) {
                String due = b.getDueDate() != null ? " (due " + b.getDueDate() + ")" : "";
                System.out.println("    • " + b.getTitle() + due);
            }
        }
        System.out.println("  " + "─".repeat(38));
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %s | Books: %d", memberId, name, contact, borrowedBooks.size());
    }
}
