package library;

import java.time.LocalDate;

/**
 * Represents a book in the library system.
 * Encapsulates all book attributes with private fields and public accessors.
 */
public class Book {
    private String isbn;
    private String title;
    private String author;
    private String genre;
    private boolean isAvailable;
    private LocalDate dueDate;
    private String borrowedByMemberId;

    public Book(String isbn, String title, String author, String genre) {
        if (isbn == null || isbn.trim().isEmpty())   throw new IllegalArgumentException("ISBN cannot be empty.");
        if (title == null || title.trim().isEmpty())  throw new IllegalArgumentException("Title cannot be empty.");
        if (author == null || author.trim().isEmpty()) throw new IllegalArgumentException("Author cannot be empty.");
        if (genre == null || genre.trim().isEmpty())  throw new IllegalArgumentException("Genre cannot be empty.");

        this.isbn   = isbn.trim();
        this.title  = title.trim();
        this.author = author.trim();
        this.genre  = genre.trim();
        this.isAvailable = true;
        this.dueDate = null;
        this.borrowedByMemberId = null;
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public String getIsbn()   { return isbn; }
    public String getTitle()  { return title; }
    public String getAuthor() { return author; }
    public String getGenre()  { return genre; }
    public boolean isAvailable() { return isAvailable; }
    public LocalDate getDueDate() { return dueDate; }
    public String getBorrowedByMemberId() { return borrowedByMemberId; }

    // ── Setters ──────────────────────────────────────────────────────────────
    public void setIsbn(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) throw new IllegalArgumentException("ISBN cannot be empty.");
        this.isbn = isbn.trim();
    }
    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) throw new IllegalArgumentException("Title cannot be empty.");
        this.title = title.trim();
    }
    public void setAuthor(String author) {
        if (author == null || author.trim().isEmpty()) throw new IllegalArgumentException("Author cannot be empty.");
        this.author = author.trim();
    }
    public void setGenre(String genre) {
        if (genre == null || genre.trim().isEmpty()) throw new IllegalArgumentException("Genre cannot be empty.");
        this.genre = genre.trim();
    }
    public void setAvailable(boolean available) { this.isAvailable = available; }
    public void setDueDate(LocalDate dueDate)   { this.dueDate = dueDate; }
    public void setBorrowedByMemberId(String id) { this.borrowedByMemberId = id; }

    // ── Display ───────────────────────────────────────────────────────────────
    public void displayInfo() {
        System.out.println("  ISBN    : " + isbn);
        System.out.println("  Title   : " + title);
        System.out.println("  Author  : " + author);
        System.out.println("  Genre   : " + genre);
        System.out.println("  Status  : " + (isAvailable ? "✅ Available" : "❌ Borrowed"));
        if (!isAvailable && dueDate != null)
            System.out.println("  Due Date: " + dueDate);
        System.out.println("  " + "─".repeat(38));
    }

    @Override
    public String toString() {
        return String.format("[%s] %s by %s (%s) - %s",
                isbn, title, author, genre,
                isAvailable ? "Available" : "Borrowed");
    }
}
