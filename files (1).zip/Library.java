package library;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Central Library class.
 * Manages collections of Books and Members and coordinates all operations.
 */
public class Library {
    private static final int LOAN_PERIOD_DAYS = 14;

    private final String libraryName;
    private List<Book>   books;
    private List<Member> members;

    public Library(String libraryName) {
        this.libraryName = libraryName;
        this.books   = new ArrayList<>();
        this.members = new ArrayList<>();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Book Operations
    // ══════════════════════════════════════════════════════════════════════════

    public boolean addBook(Book book) {
        if (findBookByIsbn(book.getIsbn()) != null) {
            System.out.println("  ⚠  A book with ISBN " + book.getIsbn() + " already exists.");
            return false;
        }
        books.add(book);
        return true;
    }

    public boolean removeBook(String isbn) {
        Book book = findBookByIsbn(isbn);
        if (book == null) { System.out.println("  ⚠  Book not found."); return false; }
        if (!book.isAvailable()) { System.out.println("  ⚠  Cannot remove a borrowed book."); return false; }
        books.remove(book);
        return true;
    }

    public Book findBookByIsbn(String isbn) {
        return books.stream()
                .filter(b -> b.getIsbn().equalsIgnoreCase(isbn))
                .findFirst().orElse(null);
    }

    /**
     * Search books by keyword across title, author, and genre (case-insensitive).
     */
    public List<Book> searchBooks(String keyword) {
        String kw = keyword.toLowerCase().trim();
        return books.stream()
                .filter(b -> b.getTitle().toLowerCase().contains(kw)
                          || b.getAuthor().toLowerCase().contains(kw)
                          || b.getGenre().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }

    public List<Book> getAvailableBooks() {
        return books.stream().filter(Book::isAvailable).collect(Collectors.toList());
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Member Operations
    // ══════════════════════════════════════════════════════════════════════════

    public boolean addMember(Member member) {
        if (findMemberById(member.getMemberId()) != null) {
            System.out.println("  ⚠  A member with ID " + member.getMemberId() + " already exists.");
            return false;
        }
        members.add(member);
        return true;
    }

    public boolean removeMember(String memberId) {
        Member member = findMemberById(memberId);
        if (member == null) { System.out.println("  ⚠  Member not found."); return false; }
        if (!member.getBorrowedBooks().isEmpty()) {
            System.out.println("  ⚠  Cannot remove member with borrowed books.");
            return false;
        }
        members.remove(member);
        return true;
    }

    public Member findMemberById(String memberId) {
        return members.stream()
                .filter(m -> m.getMemberId().equalsIgnoreCase(memberId))
                .findFirst().orElse(null);
    }

    public List<Member> getAllMembers() {
        return new ArrayList<>(members);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Borrow / Return
    // ══════════════════════════════════════════════════════════════════════════

    public boolean borrowBook(String memberId, String isbn) {
        Member member = findMemberById(memberId);
        if (member == null) { System.out.println("  ⚠  Member not found: " + memberId); return false; }

        Book book = findBookByIsbn(isbn);
        if (book == null) { System.out.println("  ⚠  Book not found: " + isbn); return false; }

        if (member.getFineAmount() > 0) {
            System.out.printf("  ⚠  Member has unpaid fines of ₹%.2f. Please clear dues first.%n",
                    member.getFineAmount());
            return false;
        }

        boolean success = member.borrowBook(book);
        if (success) {
            LocalDate due = LocalDate.now().plusDays(LOAN_PERIOD_DAYS);
            book.setDueDate(due);
            System.out.println("  ✅ Book borrowed successfully!");
            System.out.println("     Member  : " + member.getName());
            System.out.println("     Book    : " + book.getTitle());
            System.out.println("     Due Date: " + due);
        }
        return success;
    }

    public boolean returnBook(String memberId, String isbn) {
        Member member = findMemberById(memberId);
        if (member == null) { System.out.println("  ⚠  Member not found: " + memberId); return false; }

        Book book = findBookByIsbn(isbn);
        if (book == null) { System.out.println("  ⚠  Book not found: " + isbn); return false; }

        double fine = member.returnBook(book);
        if (fine < 0) return false;

        System.out.println("  ✅ Book returned successfully!");
        System.out.println("     Member: " + member.getName());
        System.out.println("     Book  : " + book.getTitle());
        if (fine > 0)
            System.out.printf("     Fine  : ₹%.2f (please pay at the counter)%n", fine);
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  Reports
    // ══════════════════════════════════════════════════════════════════════════

    public void displayAllBooks() {
        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║          ALL BOOKS (" + String.format("%3d", books.size()) + " total)         ║");
        System.out.println("  ╚══════════════════════════════════════╝");
        if (books.isEmpty()) { System.out.println("  No books in the library."); return; }
        books.forEach(Book::displayInfo);
    }

    public void displayAvailableBooks() {
        List<Book> available = getAvailableBooks();
        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║      AVAILABLE BOOKS (" + String.format("%3d", available.size()) + " found)      ║");
        System.out.println("  ╚══════════════════════════════════════╝");
        if (available.isEmpty()) { System.out.println("  No books available right now."); return; }
        available.forEach(Book::displayInfo);
    }

    public void displayAllMembers() {
        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║       ALL MEMBERS (" + String.format("%3d", members.size()) + " total)         ║");
        System.out.println("  ╚══════════════════════════════════════╝");
        if (members.isEmpty()) { System.out.println("  No registered members."); return; }
        members.forEach(Member::displayInfo);
    }

    public void displayLibraryReport() {
        long borrowed = books.stream().filter(b -> !b.isAvailable()).count();
        double totalFines = members.stream().mapToDouble(Member::getFineAmount).sum();

        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║          LIBRARY REPORT              ║");
        System.out.println("  ╚══════════════════════════════════════╝");
        System.out.println("  Library    : " + libraryName);
        System.out.println("  Date       : " + LocalDate.now());
        System.out.println("  ──────────────────────────────────────");
        System.out.println("  Total Books    : " + books.size());
        System.out.println("  Available      : " + (books.size() - borrowed));
        System.out.println("  Borrowed       : " + borrowed);
        System.out.println("  Total Members  : " + members.size());
        System.out.printf ("  Total Fines    : ₹%.2f%n", totalFines);

        // Overdue books
        List<Book> overdue = books.stream()
                .filter(b -> !b.isAvailable()
                        && b.getDueDate() != null
                        && b.getDueDate().isBefore(LocalDate.now()))
                .collect(Collectors.toList());

        System.out.println("  Overdue Books  : " + overdue.size());
        if (!overdue.isEmpty()) {
            System.out.println("  ──────────────────────────────────────");
            System.out.println("  Overdue List:");
            for (Book b : overdue) {
                long days = java.time.temporal.ChronoUnit.DAYS.between(b.getDueDate(), LocalDate.now());
                System.out.printf("    • %-30s  %d day(s) overdue%n", b.getTitle(), days);
            }
        }
        System.out.println("  " + "═".repeat(38));
    }

    public String getLibraryName() { return libraryName; }
    public int    getTotalBooks()  { return books.size(); }
    public int    getTotalMembers(){ return members.size(); }
}
